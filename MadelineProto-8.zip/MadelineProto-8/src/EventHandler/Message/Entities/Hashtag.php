<?php declare(strict_types=1);

namespace danog\MadelineProto\EventHandler\Message\Entities;

/**
 * #hashtag message entity.
 */
final class Hashtag extends MessageEntity
{
}
