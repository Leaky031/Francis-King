<?php declare(strict_types=1);

namespace danog\MadelineProto\EventHandler\Message\Entities;

/**
 * Message entity representing a $cashtag.
 */
final class Cashtag extends MessageEntity
{
}
