<?php declare(strict_types=1);

namespace danog\MadelineProto\EventHandler\Message\Entities;

/**
 * Unknown message entity.
 */
final class Unknown extends MessageEntity
{
}
