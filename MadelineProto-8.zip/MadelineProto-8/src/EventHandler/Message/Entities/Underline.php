<?php declare(strict_types=1);

namespace danog\MadelineProto\EventHandler\Message\Entities;

/**
 * Message entity representing underlined text.
 */
final class Underline extends MessageEntity
{
}
