<?php declare(strict_types=1);

namespace danog\MadelineProto\EventHandler\Message\Entities;

/**
 * Message entity representing italic text.
 */
final class Italic extends MessageEntity
{
}
