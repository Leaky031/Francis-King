# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 8.x     | :white_check_mark: |
| < 8.x   | :x:                |

## Reporting a Vulnerability

To report a security vulnerability, please write me an email at daniil@daniil.it, and/or contact me on Telegram [@danogentili](https://t.me/danogentili).
